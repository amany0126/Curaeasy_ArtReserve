package com.kh.curaeasy.notice.model.service;

public class NoticeService {

}
