package com.kh.curaeasy.notice.model.dao;

public class NoticeDao {

}
