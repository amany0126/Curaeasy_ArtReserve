package com.kh.curaeasy.review.model.service;

public class ReviewService {

}
