package com.kh.curaeasy.review.model.dao;

public class ReviewDao {

}
