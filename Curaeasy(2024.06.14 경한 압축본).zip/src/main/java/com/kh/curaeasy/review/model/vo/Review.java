package com.kh.curaeasy.review.model.vo;

public class Review {

}
