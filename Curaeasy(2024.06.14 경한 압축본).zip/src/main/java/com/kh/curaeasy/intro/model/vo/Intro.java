package com.kh.curaeasy.intro.model.vo;

public class Intro {

}
