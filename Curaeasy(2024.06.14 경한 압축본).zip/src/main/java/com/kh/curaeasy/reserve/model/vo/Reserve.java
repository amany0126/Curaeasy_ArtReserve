package com.kh.curaeasy.reserve.model.vo;

public class Reserve {

}
