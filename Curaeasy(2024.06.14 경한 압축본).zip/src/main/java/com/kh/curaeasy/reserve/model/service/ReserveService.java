package com.kh.curaeasy.reserve.model.service;

public class ReserveService {

}
