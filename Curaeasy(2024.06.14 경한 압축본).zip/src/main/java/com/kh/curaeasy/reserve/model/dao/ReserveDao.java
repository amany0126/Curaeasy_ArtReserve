package com.kh.curaeasy.reserve.model.dao;

public class ReserveDao {
	
}
