package com.kh.curaeasy.admin.model.service;

public class AdminService {

}
