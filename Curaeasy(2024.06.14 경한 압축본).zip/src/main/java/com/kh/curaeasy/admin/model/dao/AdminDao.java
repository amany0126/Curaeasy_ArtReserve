package com.kh.curaeasy.admin.model.dao;

public class AdminDao {

}
