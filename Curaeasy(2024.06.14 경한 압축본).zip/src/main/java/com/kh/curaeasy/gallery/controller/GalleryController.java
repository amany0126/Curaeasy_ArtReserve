package com.kh.curaeasy.gallery.controller;

import org.springframework.stereotype.Controller;

@Controller
public class GalleryController {
	

}
