package com.kh.curaeasy.gallery.model.dao;

public class GalleryDao {

}
