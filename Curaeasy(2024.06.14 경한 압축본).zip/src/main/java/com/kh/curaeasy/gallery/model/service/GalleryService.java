package com.kh.curaeasy.gallery.model.service;

import org.springframework.stereotype.Service;

@Service
public class GalleryService {



}
